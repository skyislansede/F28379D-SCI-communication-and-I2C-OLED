#include "F2837xD_Ipc_drivers.h"
#include "driverlib.h"
#include "device.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>


#include "led.h"
#include "oled.h"
#include "sci_test.h"
#include "button.h"
#define FIFO_SIZE       16U



Uint16 t_u16SendData[FIFO_SIZE] = { 00010366 };
Uint16 l_u16Index;

unsigned int *value;
//Uint16 nuam= {2,4,6,8,10,12};
/*EPWM1��ʼƵ�ʡ�ռ�ձ��趨*/
float epwm1_frequency=6000;
float epwm1_dutycycleA=3000;
float epwm1_dutycycleB=3000;
/*EPWM6��ʼƵ�ʡ�ռ�ձ��趨*/
float epwm6_frequency=7500;
float epwm6_dutycycleA=3750;
float epwm6_dutycycleB=3750;
/*EPWM1ռ�ձ�Ϊ %*/
float epwm1_dutycycle_A=50;
float epwm1_dutycycle_B=50;
/*EPWM6ռ�ձ�Ϊ %*/
float epwm6_dutycycle_A=50;
float epwm6_dutycycle_B=50;
char *msg;




void main(void)
{
/*����ģʽ�л�*/
#ifdef _STANDALONE
#ifdef _FLASH

    IPCBootCPU2(C1C2_BROM_BOOTMODE_BOOT_FROM_FLASH);
#else

    IPCBootCPU2(C1C2_BROM_BOOTMODE_BOOT_FROM_RAM);
#endif
#endif

    /*�豸��ʼ��*/
    Device_init();
    /*GPIO��ʼ��*/
    Device_initGPIO();

    /*��ʼ������� PIE registers. �ر� CPU interrupts.*/
    Interrupt_initModule();
    /*��ʼ�� PIE vector table ��ָ�� the shell Interrupt*/
    Interrupt_initVectorTable();
    /*�������ж�*/
    Interrupt_enableMaster();


    led_Init();
    OLED_Init();
    UART_GPIO_init();
    gpio_init();
    SCI_A_init();

    // Enable Global Interrupt (INTM) and realtime interrupt (DBGM)
    EINT;
    ERTM;




    //    msg=0;
    //    value=++msg;
    //    OLED_ShowString(0,0,"Va:",12,1);
    //    OLED_ShowNum(0,32,value,1,12,1);
    //    show_guiyinum(nuam);
    //    OLED_ShowNum(24,0,"Vb:",1,12,1);
    //    OLED_ShowNum(0,24,value,1,12,1);
    //    OLED_Refresh();

    int epwm6_a1,epwm6_b1,epwm6_c1,epwm6_a2,epwm6_b2,epwm6_c2;

    epwm1_dutycycle_A=((float)(epwm1_dutycycleA/epwm1_frequency))*10000;
    epwm1_dutycycle_B=((float)(epwm1_dutycycleB/epwm1_frequency))*10000;
    epwm6_dutycycle_A=((float)(epwm6_dutycycleA/epwm6_frequency))*10000;
    epwm6_dutycycle_B=((float)(epwm6_dutycycleB/epwm6_frequency))*10000;


    epwm6_a1=(int)(epwm6_dutycycle_A/100);
    epwm6_b1=(int)(epwm6_dutycycle_A/10)%10;
    epwm6_c1=(int)epwm6_dutycycle_A%10;
    OLED_ShowNum(76,48,epwm6_a1,2,12,1);
    OLED_ShowString(92,48,".",12,1);
    OLED_ShowNum(96,48,epwm6_b1,1,12,1);
    OLED_ShowNum(104,48,epwm6_c1,1,12,1);

    epwm6_a2=(int)(epwm6_dutycycle_B/100);
    epwm6_b2=(int)(epwm6_dutycycle_B/10)%10;
    epwm6_c2=(int)epwm6_dutycycle_B%10;
    OLED_ShowNum(14,48,epwm6_a2,2,12,1);
    OLED_ShowString(30,48,".",12,1);
    OLED_ShowNum(34,48,epwm6_b2,1,12,1);
    OLED_ShowNum(42,48,epwm6_c2,1,12,1);

    OLED_Refresh();
    msg=12345;


    while(1)
    {
        if(GPIO_readPin(97) == 0)
               {
                   GPIO_writePin(DEVICE_GPIO_PIN_LED2, 1);
                   DEVICE_DELAY_US(10000);
                   GPIO_writePin(DEVICE_GPIO_PIN_LED2, 0);
                   DEVICE_DELAY_US(10000);
               }
               if(GPIO_readPin(97)==1)
               {
                   GPIO_writePin(DEVICE_GPIO_PIN_LED2, 1);
                   DEVICE_DELAY_US(10000);
               }
      SCI_writeCharArray(SCIA_BASE, (uint16_t *)epwm6_b2, 1);
        SCI_writeCharArray(SCIA_BASE, (uint16_t *)epwm6_c2, 1);
       SCI_writeCharArray(SCIA_BASE, (uint16_t *)epwm6_a2, 1);
            //   while(ScicRegs.SCIFFRX.bit.RXFFST == 0) { }
               scia_msg(msg);
        LED1_Toggle();
        DEVICE_DELAY_US(5000);
        LED2_Toggle();
               }

//    for (l_u16Index = 0; l_u16Index < FIFO_SIZE; l_u16Index++)
//    {
        /* Send data */
//        ScicRegs.SCITXBUF.all = t_u16SendData[l_u16Index];
//        LED1_Toggle();
//        DEVICE_DELAY_US(500);
//        LED2_Toggle();
  //  }



}









