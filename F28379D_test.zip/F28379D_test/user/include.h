/*
 * include.h
 *
 *  Created on: 2022��7��10��
 *      Author: sqxqian
 */

#ifndef USER_INCLUDE_H_
#define USER_INCLUDE_H_

typedef unsigned char      Uint8;



#endif /* USER_INCLUDE_H_ */
