/*
 * button.h
 *
 *  Created on: Sep 16, 2022
 *      Author: DELL
 */

#ifndef BSP_BUTTON_BUTTON_H_
#define BSP_BUTTON_BUTTON_H_

void gpio_init(void);



#endif /* BSP_BUTTON_BUTTON_H_ */
